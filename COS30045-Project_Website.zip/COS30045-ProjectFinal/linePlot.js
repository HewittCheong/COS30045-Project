function init(){
//Line Chart
// append the svg object to the body of the page
var margin = {top: 10, right: 100, bottom: 40, left: 80},
    width = 800 - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

const svg2 = d3.select("#line")
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

//Read the data
d3.csv("solar.csv", function(data) {

    const groups = data.map(d => (d.year))
    var allGroup = ["US", "UK"]

   // add the options to the button
    d3.select("#selectButton")
      .selectAll('myOptions')
      .data(allGroup)
      .enter()
      .append('option')
      .text(function (d) { return d; }) // text showed in the menu
      .attr("value", function (d) { return d; }) // corresponding value returned by the button

d3.select("svg")
    .append("text")
    .attr("x", 350)
    .attr("y", 15)
    .attr("text-anchor", "middle")
    .text("United States VS United Kingdom Solar Consumption, 2011-2021")
    .style("fill", "black")
    .style("font-size", 20)
    .style("font-family", "Times New Roman Black");

    // A color scale: one color for each group
    const myColor = d3.scaleOrdinal()
      .domain(allGroup)
      .range(d3.schemeSet2);

  // Add X axis
  var x = d3.scaleBand()
      .domain(groups)
      .range([0, width])
      .padding([0.2])
  svg2.append("g")
    .attr("transform",  "translate(-23," + height + ")")
    .call(d3.axisBottom(x).tickSizeOuter(0));

    // Add Y axis
    var y = d3.scaleLinear()
      .domain([0, d3.max(data, function(d) { return +d.US + 20; })])
      .range([ height, 0 ]);
    svg2.append("g")
      .attr("transform", "translate(-23,0)")
      .call(d3.axisLeft(y));

// Add X axis label:
svg2.append("text")
    .attr("text-anchor", "end")
    .attr("x", "330")
   .attr("y", "590")
   .attr("fill", "#0000D1")
   .text("Year")
   .style("font-size", 20)
   .style("font-family", "Times New Roman Black");

// Y axis label:
svg2.append("text")
    .attr("text-anchor", "end")
    .attr("transform", "rotate(-90)")
    .attr("x", "-175")
    .attr("y", "-60")
    .attr("fill", "#0000D1")
    .text("Electricity from solar (TWh)")
    .style("font-size", 20)
    .style("font-family", "Times New Roman Black");


    // create a tooltip
    var Tooltip = d3.select("#line")
      .append("div")
      .style("opacity", 0)
      .attr("class", "tooltip")
      .style("background-color", "white")
      .style("border", "solid")
      .style("border-width", "2px")
      .style("border-radius", "5px")
      .style("padding", "5px")
      .style("position", "absolute")

    // Three function that change the tooltip when user hover / move / leave a cell
    var mouseover = function(d) {
      Tooltip
        .style("opacity", 1)
    }
    var mousemove1 = function(d) {
      Tooltip
        .html("Exact value: " + d.US)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY + 10) + "px")
    }
    var mousemove2 = function(d) {
      Tooltip
        .html("Exact value: " + d.value)
        .style("left", (d3.event.pageX + 10) + "px")
        .style("top", (d3.event.pageY + 10) + "px")
    }
    var mouseleave = function(d) {
      Tooltip
        .style("opacity", 0)
    }

    // Add one dot in the legend for each name.
    var size = 20
    svg2.selectAll("myrect")
      .data(allGroup)
      .enter()
      .append("rect")
        .attr("x", 600)
        .attr("y", function(d,i){ return 250 + i*(size+5)}) // 100 is where the first dot appears. 25 is the distance between dots
        .attr("width", size)
        .attr("height", size)
        .style("fill", function(d){ return myColor(d)})

    // Add one dot in the legend for each name.
    svg2.selectAll("mylabels")
      .data(allGroup)
      .enter()
      .append("text")
        .attr("x", 600 + size*1.2)
        .attr("y", function(d,i){ return 250 + i*(size+5) + (size/2)})
        .style("fill", function(d){ return myColor(d)})
        .text(function(d){ return d})
        .attr("text-anchor", "left")
        .style("alignment-baseline", "middle")
		.style("font-size", 20)

  // Add the line
    var line=svg2.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", function(d){return myColor("US")})
      .attr("stroke-width", 1.5)
      .attr("d", d3.line()
        .x(function(d) { return x(d.year) })
        .y(function(d) { return y(d.US) })
        )

      var circle = svg2
        .append("g")
        .selectAll("dot")
        .data(data)
        .enter()
        .append("circle")
          .attr("cx", function(d) { return x(d.year) } )
          .attr("cy", function(d) { return y(d.US) } )
          .attr("r", 5)
          .attr("fill", "#69b3a2")
          .on("mouseover", mouseover)
          .on("mousemove", mousemove1)
          .on("mouseleave", mouseleave)

     // A function that update the chart
    function update(selectedGroup) {

      // Create new data with the selection?
       const dataFilter = data.map(function(d){return { year:d.year, value:d[selectedGroup]} })

      // Give these new data to update line
      line
          .datum(dataFilter)
          .transition()
          .duration(1000)
          .attr("d", d3.line()
            .x(function(d) { return x(d.year) })
            .y(function(d) { return y(d.value) })
          )
          .attr("stroke", function(d){ return myColor(selectedGroup) })

      circle
          .data(dataFilter)
          .transition()
          .duration(1000)
          .attr("cx", function(d) { return x(+d.year) })
          .attr("cy", function(d) { return y(+d.value) })
          .attr("fill", function(d){ return myColor(selectedGroup) })

      circle
          .on("mouseover", mouseover)
          .on("mousemove", mousemove2)
          .on("mouseleave", mouseleave)
    	}

    // When the button is changed, run the updateChart function
    d3.select("#selectButton").on("change", function(event,d) {
        // recover the option that has been chosen
        const selectedOption = d3.select(this).property("value")
        // run the updateChart function with this selected option
        update(selectedOption)
      })
})
}
window.onload = init;
