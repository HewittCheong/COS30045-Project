function init(){

    // set the dimensions and margins of the graph
var margin = {top: 20, right: 100, bottom: 40, left: 90},
    width = 800 - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

    // append the svg object to the body of the page
    var svg = d3.select("#GroupedBarPlotUK")
                .append("svg")
                .attr("width", width + margin.left + margin.right)
                .attr("height", height + margin.top + margin.bottom)
                .append("g")
                .attr("transform", `translate(${margin.left},${margin.top})`);

    // Parse the Data
    d3.csv("Electricity Generation from Solar Energy in US and UK from 2011 to 2021.csv", function(data) {

      // List of subgroups = header of the csv files = soil condition here
      var subgroups = data.columns.slice(1)

      // List of groups
      var groups = d3.map(data, function(d){return(d.Year)}).keys()

      var allGroup = ["US", "UK"];

      // Add X axis
      var x = d3.scaleBand()
          .domain(groups)
          .range([0, width])
          .padding([0.2])

      svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.axisBottom(x).tickSize(0));

      // Add Y axis
      var y = d3.scaleLinear()
        .domain([0, d3.max(data, function(d) { return +d.US + 10000})])
        .range([ height, 0 ]);
      svg.append("g")
        .call(d3.axisLeft(y));

      // Another scale for subgroup position
      var xSubgroup = d3.scaleBand()
        .domain(subgroups)
        .range([0, x.bandwidth()])
        .padding([0.05])

      // color palette = one color per subgroup
      var color = d3.scaleOrdinal()
        .domain(subgroups)
        .range(['#e41a1c','#377eb8'])

      var tooltip = d3.select("#GroupedBarPlotUK")
                      .append("div")
                      .style("opacity", 0)
                      .attr("class", "tooltip")
                      .style("background-color", "white")
                      .style("border", "solid")
                      .style("border-width", "2px")
                      .style("border-radius", "5px")
                      .style("padding", "5px")
                      .style("position", "absolute")

      // Three function that change the tooltip when user hover / move / leave a cell
      var mouseover = function(d) {
        tooltip
          .style("opacity", 1)
        d3.selectAll("rect")
          .style("opacity", 0.4)
        d3.select(this)
          .style("stroke", "black")
          .style("opacity", 1)
      }
      var mousemove = function(d) {
        tooltip
          .html("Country: " + d.key + "<br>Value: " + d.value)
          .style("left", (d3.event.pageX + 10) + "px")
          .style("top", (d3.event.pageY + 10) + "px")
      }
      var mouseleave = function(d) {
        tooltip
          .style("opacity", 0)
        d3.select(this)
          .style("stroke", "none")
          .style("opacity", 1)
        d3.selectAll("rect")
          .style("opacity", 1)
      }
// Add X axis label:
svg.append("text")
    .attr("text-anchor", "end")
    .attr("x", "350")
   .attr("y", "580")
   .attr("fill", "#8B0000")
   .text("Year")
   .style("font-size", 20)
   .style("font-family", "Times New Roman Black");

// Y axis label:
svg.append("text")
    .attr("text-anchor", "end")
    .attr("transform", "rotate(-90)")
    .attr("x", "-160")
    .attr("y", "-60")
    .attr("fill", "#8B0000")
    .text("Electricity Generation")
    .style("font-size", 20)
    .style("font-family", "Times New Roman Black");

	 d3.select("svg")
    .append("text")
    .attr("x", 450)
    .attr("y", 30)
    .attr("text-anchor", "middle")
    .text("Electricity Generation from Solar Energy in US and UK from 2011 to 2021")
    .style("fill", "#301934")
    .style("font-size", 20)
    .style("font-family", "Times New Roman Black");


    // What to do when one group is hovered
    var highlight = function(d){
      console.log(d)
      // reduce opacity of all groups
      d3.selectAll(".myArea").style("opacity", .1)
      // expect the one that is hovered
      d3.select("."+d).style("opacity", 1)
    }

    // And when it is not hovered anymore
    var noHighlight = function(d){
      d3.selectAll(".myArea").style("opacity", 1)
    }

	      // Add one dot in the legend for each name.
    var size = 20
    svg.selectAll("myrect")
      .data(subgroups)
      .enter()
      .append("rect")
        .attr("x", 650)
        .attr("y", function(d,i){ return 250 + i*(size+5)}) // 100 is where the first dot appears. 25 is the distance between dots
        .attr("width", size)
        .attr("height", size)
        .style("fill", function(d){ return color(d)})
        .on("mouseover", highlight)
        .on("mouseleave", noHighlight)

    // Add one dot in the legend for each name.
    svg.selectAll("mylabels")
      .data(subgroups)
      .enter()
      .append("text")
        .attr("x", 650 + size*1.2)
        .attr("y", function(d,i){ return 250 + i*(size+5) + (size/2)}) // 100 is where the first dot appears. 25 is the distance between dots
        .style("fill", function(d){ return color(d)})
        .text(function(d){ return d})
        .attr("text-anchor", "left")
        .style("alignment-baseline", "middle")
		.style("font-size", 20)
        .on("mouseover", highlight)
        .on("mouseleave", noHighlight)

      // Show the bars
      var bar = svg.append("g")
        .selectAll("g")
        .data(data)
        .enter()
        .append("g")
          .attr("transform", function(d) { return "translate(" + x(d.Year) + ",0)"; })
        .selectAll("rect")
        .data(function(d) { return subgroups.map(function(key) { return {key: key, value: d[key]}; }); })
        .enter().append("rect")
          .attr("x", function(d) { return xSubgroup(d.key); })
          .attr("y", function(d) { return y(d.value); })
          .attr("width", xSubgroup.bandwidth())
          .attr("height", function(d) { return height - y(d.value); })
          .attr("fill", function(d) { return color(d.key); })
          .on("mouseover", mouseover)
          .on("mousemove", mousemove)
          .on("mouseleave", mouseleave);
  })
}

window.onload = init;
